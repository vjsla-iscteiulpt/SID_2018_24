package MySQLConnection;

import java.sql.*;

import SensorConnection.LightReading;
import SensorConnection.TemperatureReading;

public class MySQLConnection {

	private Connection con;

	public MySQLConnection() {

	}

	public synchronized void connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/mydb?useUnicode=true&useJDBCCompliantTimezoneShift=true&serverTimezone=GMT%2B00:00",
					"root", "LightYagamiisalive1994");
			// here sonoo is database name, root is username and password
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void disconnect() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public synchronized void sendTemperature(TemperatureReading r) {
		try {
			PreparedStatement preparedStmt = con
					.prepareStatement("insert into Medi��esTemperatura (DataM, Valor) values(?, ?)");
			preparedStmt.setTimestamp(1, Timestamp.from(r.getInstant()));
			preparedStmt.setDouble(2, r.getTemperature());
			preparedStmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public synchronized void sendLight(LightReading r) {
		try {
			PreparedStatement preparedStmt = con
					.prepareStatement("insert into Medi��esLuminosidade (DataM, Valor) values(?, ?)");
			preparedStmt.setTimestamp(1, Timestamp.from(r.getInstant()));
			preparedStmt.setInt(2, r.getLight());
			preparedStmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
