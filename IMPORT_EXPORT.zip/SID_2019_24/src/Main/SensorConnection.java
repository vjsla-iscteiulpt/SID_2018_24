package Main;

import MongoConnection.MongoWrite;
import SensorConnection.PahoConnection;
import SensorConnection.SensorManager;

public class SensorConnection {

	public static void main(String[] args) {
		MongoWrite mongo = new MongoWrite();
		mongo.connect();
		SensorManager sm = new SensorManager(mongo);
		PahoConnection pc = new PahoConnection(sm);
		pc.connect();
	}

}