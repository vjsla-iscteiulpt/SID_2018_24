package Main;

import java.util.ArrayList;

import MongoConnection.MongoRead;
import MySQLConnection.MySQLConnection;
import SensorConnection.LightReading;
import SensorConnection.TemperatureReading;

public class DatabaseConnection {

	private static MongoRead mongoRead;
	private static MySQLConnection mysql;

	private static class TemperatureSender extends Thread {

		@Override
		public void run() {
			try {
				while (!interrupted()) {
					ArrayList<TemperatureReading> t = mongoRead.getTemperatures();
					for (TemperatureReading r : t)
						mysql.sendTemperature(r);
					Thread.sleep(1000);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	private static class LightSender extends Thread {

		@Override
		public void run() {
			try {
				while (!interrupted()) {
					ArrayList<LightReading> t = mongoRead.getLights();
					for (LightReading r : t)
						mysql.sendLight(r);
					Thread.sleep(1000);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}


	public static void main(String[] args) {
		mongoRead = new MongoRead();
		mongoRead.connect();
		mysql = new MySQLConnection();
		mysql.connect();
		Thread ts = new TemperatureSender();
		ts.start();
		Thread tl = new LightSender();
		tl.start();
	}

}
