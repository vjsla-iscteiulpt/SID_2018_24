package SensorConnection;

import java.time.Instant;

public class LightReading extends Reading {
	
	private int light;

	public LightReading(Instant instant, int light) {
		super(instant);
		this.light = light;
	}

	public int getLight() {
		return light;
	}
	
	@Override
	public boolean equals(Object a) {
		return super.equals(a) && ((LightReading)a).getLight() == light;
	}
	
}
