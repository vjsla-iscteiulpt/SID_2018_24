package SensorConnection;

import java.time.Instant;

public class TemperatureReading extends Reading {
	
	private double temperature;

	public TemperatureReading(Instant instant, double temperature) {
		super(instant);
		this.temperature = temperature;
	}

	public double getTemperature() {
		return temperature;
	}
	
	@Override
	public boolean equals(Object a) {
		return super.equals(a) && ((TemperatureReading)a).getTemperature() == temperature;
	}
	
}