package SensorConnection;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class PahoConnection implements MqttCallbackExtended {

	private static String TOPIC = "/sid_lab_2019_2";
	private static int QOS = 0;
	private static String BROKER = "tcp://iot.eclipse.org:1883";
	private static String BROKER2 = "tcp://broker.mqtt-dashboard.com:1883";
	private static String CLIENT_ID = "Grupo_24";

	private MqttClient client;
	private MqttConnectOptions connOpts;
	private MemoryPersistence persistence;
	private SensorManager manager;

	public PahoConnection(SensorManager manager) {
		this.manager = manager;
		persistence = new MemoryPersistence();
	}

	public void connect() {
		try {
			client = new MqttClient(BROKER2, CLIENT_ID, persistence);
			connOpts = new MqttConnectOptions();
			System.out.println("Connecting to broker: " + BROKER2);
			client.connect(connOpts);
			client.setCallback(this);
			System.out.println("Connected");
			subscribe(TOPIC, QOS);
		} catch (MqttException me) {
			System.out.println("reason " + me.getReasonCode());
			System.out.println("msg " + me.getMessage());
			System.out.println("loc " + me.getLocalizedMessage());
			System.out.println("cause " + me.getCause());
			System.out.println("excep " + me);
			me.printStackTrace();
		}
	}

	public void disconnect() {
		try {
			client.disconnect();
			System.out.println("Disconnected");
		} catch (MqttException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void connectionLost(Throwable cause) {
		// TODO Auto-generated method stub

	}

	public void publish(String topicName, int qos, String messageString) throws MqttException {
		System.out.println("Publishing message: " + messageString);
		MqttMessage message = new MqttMessage(messageString.getBytes());
		message.setQos(qos);
		client.publish(TOPIC, message);
		System.out.println("Message published");
	}

	public void subscribe(String topic, int qos) throws MqttException {
		System.out.println("Subscribing to topic " + topic + " qos " + qos);
		client.subscribe(topic, qos);
		System.out.println("Subscribed to topic " + topic);
	}

	@Override
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		System.out.println("Received Message from Topic: " + topic + " with text: " + message);
		manager.writeReading(message.toString());
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
		// TODO Auto-generated method stub

	}

	@Override
	public void connectComplete(boolean reconnect, String serverURI) {
		// TODO Auto-generated method stub

	}

}
