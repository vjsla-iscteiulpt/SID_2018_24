package SensorConnection;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.HashMap;
import java.util.TreeSet;

import com.google.gson.*;

import MongoConnection.MongoWrite;

public class SensorManager {

	private static int READINGS_MINIMUM_SIZE = 5;

	private class ReadingsSender extends Thread {

		@Override
		public void run() {
			try {
				while (!interrupted()) {
					synchronized (readings) {
						if (readings.size() <= READINGS_MINIMUM_SIZE)
							readings.wait();
						else {
							Reading r = readings.pollLast();
							if (r instanceof LightReading)
								mongo.sendLuminosidade((LightReading) r);
							else
								mongo.sendTemperatura((TemperatureReading) r);
						}
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	private MongoWrite mongo;
	private TreeSet<Reading> readings;

	public SensorManager(MongoWrite mongo) {
		this.mongo = mongo;
		readings = new TreeSet<Reading>();
		(new ReadingsSender()).start();
	}

	private HashMap<String, String> readValues(String s) {
		HashMap<String, String> values = new HashMap<String, String>();
		boolean key = true, reading = false;
		int readingCounter = 0;
		String keyString = "";
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == '"') {
				if (reading) {
					if (key)
						keyString = s.substring(readingCounter, i);
					else
						values.put(keyString, s.substring(readingCounter, i));
					key = !key;
				} else
					readingCounter = i + 1;
				reading = !reading;
			}
		}
		return values;
	}

	public void writeReading(String s) {
		System.out.println("Checking JSON message...");
		HashMap<String, String> values = readValues(s);
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy'-'HH:mm:ss");
		Instant i = null;
		try {
			i = df.parse(values.get("dat") + "-" + values.get("tim")).toInstant();
			if (values.get("cell") != null) {
				synchronized (readings) {
					readings.add(new LightReading(i, Integer.parseInt(values.get("cell"))));
					readings.notify();
				}
			}
			if (values.get("tmp") != null) {
				synchronized (readings) {
					readings.add(new TemperatureReading(i, Double.parseDouble(values.get("tmp"))));
					readings.notify();
				}
			}
			System.out.println("Values Saved with Success!");
		} catch (ParseException e) {
			System.out.println("Invalid Sensor JASON object!");
		}

	}

//	public void writeReading(String s) {
//		try {
//			System.out.println("Checking JSON message...");
//			JsonObject o = new JsonParser().parse(s).getAsJsonObject();
//			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy'-'HH:mm:ss");
//			Date date = null;
//			try {
//				date = df.parse(o.get("dat").getAsString() + "-" + o.get("tim").getAsString());
//			} catch (ParseException e) {
//				e.printStackTrace();
//			}
//			System.out.println("Valid JSON Object \nSaving Values...");
//			LightReading r = new LightReading(date, o.get("cell").getAsInt());
//			lightReadings.add(r);
//			tempReadings.add(new TemperatureReading(date, o.get("tmp").getAsDouble()));
//			System.out.println("Values Saved with Success!");
//		} catch (JsonParseException | IllegalStateException e) {
//			System.out.println("Invalid Sensor JASON object!");
//		}
//	}

}
