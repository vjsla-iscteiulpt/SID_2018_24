package SensorConnection;

import java.time.Instant;

public abstract class Reading implements Comparable<Reading> {

	private Instant instant;

	public Reading(Instant instant) {
		this.instant = instant;
	}

	public Instant getInstant() {
		return instant;
	}

	@Override
	public int compareTo(Reading o) {
		return (this == o) || 
				(((this instanceof LightReading && o instanceof LightReading) || 
						(this instanceof TemperatureReading && o instanceof TemperatureReading)) 
						&& instant.compareTo(o.getInstant()) == 0) ? 0 : instant.compareTo(o.getInstant()) == 0 ? 1 : instant.compareTo(o.getInstant());
	}
	
}
