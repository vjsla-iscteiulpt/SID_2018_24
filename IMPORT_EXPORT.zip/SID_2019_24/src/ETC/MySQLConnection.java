package ETC;

import java.sql.*;
import java.text.DateFormat;

public class MySQLConnection {
	
	private Connection con;

	public MySQLConnection() {

	}

	public void connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
			// here sonoo is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from emp");
			while (rs.next())
				System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public synchronized void sendTemperature(Date date, int value) {
		try {
			Statement stmt = con.createStatement();
//			DateFormat df = new DateFormat("YYYY-MM-DD hh:mm:ss");
			stmt.executeQuery("insert into Medi��esTemperatura (DataM, Valor) values(" + date + ", " + value + ")");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public synchronized void sendLight(Date date, int value) {
		try {
			Statement stmt = con.createStatement();
			stmt.executeQuery("insert into Medi��esLuminosidade (DataM, Valor) values(" + date + ", " + value + ")");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
