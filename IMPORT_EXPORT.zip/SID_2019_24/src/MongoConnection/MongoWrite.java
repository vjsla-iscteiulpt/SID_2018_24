package MongoConnection;

import com.mongodb.client.*;

import SensorConnection.LightReading;
import SensorConnection.TemperatureReading;

import org.bson.Document;

public class MongoWrite   {
	
	private static String HOST = "mongodb://localhost:27017";
	private static String DATABASE = "mydb";
	
	private MongoClient client;
	private MongoDatabase database;
	private MongoCollection<Document> temperatura, luminosidade;
	
	public MongoWrite() {
		
	}
	
	public void connect() {
		client = MongoClients.create(HOST);
		database = client.getDatabase(DATABASE);
		temperatura = database.getCollection("Temperatura");
		luminosidade = database.getCollection("Luminosidade");
	}
	
	public void disconnect() {
		client.close();
	}
	
	public void sendTemperatura(TemperatureReading tr) {
		System.out.println("A escrever a temperatura no Mongo.");
		Document d = new Document("Data", tr.getInstant()).append("Valor", tr.getTemperature()).append("Retrieved", false);
		temperatura.insertOne(d);
		System.out.println("Temperatura escrita com sucesso!");
	}
	
	public void sendLuminosidade(LightReading lr) {
		System.out.println("A escrever a luminosidade no Mongo.");
		Document d = new Document("Data", lr.getInstant()).append("Valor", lr.getLight()).append("Retrieved", false);
		luminosidade.insertOne(d);
		System.out.println("Luminosidade escrita com sucesso!");
	}
	
}	
