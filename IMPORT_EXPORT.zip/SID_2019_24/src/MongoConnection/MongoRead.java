package MongoConnection;

import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

import SensorConnection.LightReading;
import SensorConnection.TemperatureReading;

import java.util.*;

import org.bson.Document;

public class MongoRead   {
	
	private static String HOST = "mongodb://localhost:27017";
	private static String DATABASE = "mydb";
	
	private MongoClient client;
	private MongoDatabase database;
	private MongoCollection<Document> temperatura, luminosidade;
	
	public MongoRead() {
		
	}
	
	public void connect() {
		client = MongoClients.create(HOST);
		database = client.getDatabase(DATABASE);
		temperatura = database.getCollection("Temperatura");
		luminosidade = database.getCollection("Luminosidade");
	}
	
	public void disconnect() {
		client.close();
	}
	
	public synchronized ArrayList<TemperatureReading> getTemperatures() {
		ArrayList<TemperatureReading> tmp = new ArrayList<TemperatureReading>();
		for(Document d : temperatura.find(new Document("Retrieved", false))) {
			tmp.add(new TemperatureReading(d.getDate("Data").toInstant(), d.getDouble("Valor")));
			temperatura.updateMany(Filters.eq("Retrieved", false), Updates.set("Retrieved", true));
		}
		return tmp;
	}
	
	public synchronized ArrayList<LightReading> getLights() {
		ArrayList<LightReading> tmp = new ArrayList<LightReading>();
		for(Document d : luminosidade.find(new Document("Retrieved", false))) {
			tmp.add(new LightReading(d.getDate("Data").toInstant(), d.getInteger("Valor")));
			luminosidade.updateMany(Filters.eq("Retrieved", false), Updates.set("Retrieved", true));
		}
		return tmp;
	}
	
}